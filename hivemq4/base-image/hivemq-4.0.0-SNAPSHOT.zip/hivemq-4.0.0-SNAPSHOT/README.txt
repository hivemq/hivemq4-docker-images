Quickstart
=========

Linux/Unix/MacOSX
-----------------
cd <hivemq_install_directory>/bin
chmod 755 run.sh
./run.sh


Windows
--------

Run:
right click on bin\run.bat
select "Run as administrator"